#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    void *Buffer=NULL;
    int Ti=0,Tf=0,Td=0, cont, Tempi;
    float Tempf;
    double Tempd;
    char x='a';


    for(; x!= 's'; ){
        printf (" para add int digite i\n para add float digite f\n para add double digite d\n para sair digite s\n");
        scanf ("%c", &x);
        if (x=='i'){
            if (Buffer==NULL)            {
                Buffer=malloc (sizeof (int));
                if (Buffer==NULL) printf("deu RUIM\n");
                printf ("digite o valor de int");
                scanf ("%d", Tempi);
                Buffer = Tempi ;
                Ti++;
            }
        
            else {
                void *Deleta;
                Deleta=Buffer;
                void *Buffertemp= malloc( (Ti+1)*(sizeof(int))+Tf*(sizeof(float))+Td*(sizeof(double)));
                if (Buffertemp==NULL) printf("deu RUIM\n");
                for (cont = 0; cont <Ti ;cont++){
                    (int*) Buffertemp [cont*sizeof (int)] = (int*) Buffer[cont*sizeof (int)];
                }
                Ti++;
                printf("diga o valor do inteiro\n ");
                scanf ("%d",  &Buffertemp [(Ti*sizeof (int))]);
         //       (int*) Buffertemp [(Ti*sizeof (int))] = Tempi;
                for (cont = 0; cont <Tf ;cont++){
                    (float*) Buffertemp [(cont*sizeof (float))+(Ti*sizeof (int))] = (float*) Buffer[(cont*sizeof (float))+((Ti-1)*sizeof (int))];
                }
                for (cont = 0; cont <Td ;cont++){
                    (double*) Buffertemp [(cont*sizeof (double))+(Ti*sizeof (int))+(Tf*sizeof (float))] = (double*) Buffer[(cont*sizeof (double))+((Ti-1)*sizeof (int))+(Tf*sizeof (float))];
                }
                Buffer = Buffertemp;
                free(Deleta);
            }
        }
        else if (x=='f'){
            if (Buffer==NULL)            {
                Buffer=malloc (sizeof (float));
                if (Buffer==NULL) printf("deu RUIM\n");
                printf ("diga o valor do Float");
                scanf ("%f", (float*)Buffer);
              //  Buffer= (void*) Tempf ;
                Tf++;
            }
            else {
                void *Deleta;
                Deleta=Buffer;
                void *Buffertemp= malloc( Ti*(sizeof(int))+((Tf+1)*(sizeof(float)))+(Td*(sizeof(double))));
                if (Buffertemp==NULL) printf("deu RUIM\n");
                for (cont = 0; cont <Ti ;cont++){
                    (int*) Buffertemp [cont*sizeof (int)] = (int*) Buffer[cont*sizeof (int)];
                }
                for (cont = 0; cont <Tf ;cont++){
                    (float*) Buffertemp [(cont*sizeof (float))+(Ti*sizeof (int))] = (float*) Buffer[(cont*sizeof (float))+((Ti)*sizeof (int))];
                }
                Tf++;
                printf("diga o valor do Float\n ");
                scanf ("%f", &Buffertemp [(Ti*sizeof (int))+(Tf*sizeof(float))]);
        //        (float*) Buffertemp [(Ti*sizeof (int))+(Tf*sizeof(float))] = Tempf;
                for (cont = 0; cont <Td ;cont++){
                    (double*) Buffertemp [(cont*sizeof (double))+(Ti*sizeof (int))+(Tf*sizeof (float))] = (double*) Buffer[(cont*sizeof (double))+((Ti)*sizeof (int))+((Tf-1)*sizeof (float))];
                }
                Buffer = Buffertemp;
                free(Deleta);
            }
        }
        else if (x=='d'){
            if (Buffer==NULL)            {
                Buffer=malloc (sizeof (double));
                if (Buffer==NULL) printf("deu RUIM\n");
                printf("diga o valor do Double\n ");
                scanf ("%lf",  &Buffer);
            //    Buffer = (void*)Tempd;
                Td++;
            }
            else {
                Td++;
                Buffer = realloc( Buffer ,(Ti*(sizeof(int)))+(Tf*(sizeof(float)))+(Td*(sizeof(double))));
                if (Buffer==NULL) printf("deu RUIM\n");
                printf("diga o valor do Double\n ");
                scanf ("%lf",  &Buffer[(Ti*sizeof (int))+(Tf*sizeof(float))+(Td*sizeof(double))]);
            //   (double*) Buffer[(Ti*sizeof (int))+(Tf*sizeof(float))+(Td*sizeof(double))] = Tempd;
            }
        }
        else if (x=='s'){
            for( cont=0; cont < Ti;cont ++){
              //  Tempi = (int*) Buffer[cont*sizeof (int)];
                printf("%d", &Buffer[cont*sizeof (int)]);
            }
            for(cont=0; cont < Tf;cont ++){
             //   Tempf = (float*) Buffer[(cont*sizeof (float))+(Ti*sizeof (int))];
                printf("%f", &Buffer[(cont*sizeof (float))+(Ti*sizeof (int))]);
            }
            for(cont=0; cont < Td;cont ++){
             //   Tempd = (double*) Buffer[(cont*sizeof (double))+(Ti*sizeof (int))+(Tf*sizeof (float))];
                printf("%lf", &Buffer[(cont*sizeof (double))+(Ti*sizeof (int))+(Tf*sizeof (float))]);
            }
        }
        else printf (" Ta errado isso ai po\n Denovo\n");
    } 
        free(Buffer);
    return 0;
}